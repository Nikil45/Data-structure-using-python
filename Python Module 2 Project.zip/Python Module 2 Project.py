Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import pandas as pd
from tabulate import tabulate
SyntaxError: multiple statements found while compiling a single statement
import pandas as pd

from tabulate import tabulate
data = {
    "Data field identifier": [
        "player_name", "player_age", "country", "teams_played",
        "formats_played", "total_runs", "batting_average",
        "centuries", "is_active_player", "runs_by_format"
    ],
... 
...     "Data type": [
...         "String", "Integer", "String", "List",
...         "List", "Integer", "Float",
...         "Integer", "Boolean", "Dictionary"
...     ],
... 
...     "Example": [
...         "Virat Kohli",
...         36,
...         "India",
...         ["India", "RCB"],
...         ["Test", "ODI", "T20"],
...         26000,
...         52.3,
...         80,
...         True,
...         {"Test": 9000, "ODI": 13000, "T20": 4000}
...     ],
... 
...     "Reason": [
...         "Names contain letters and characters",
...         "Age is a whole number",
...         "Country names are text",
...         "Player can play for multiple teams",
...         "Player can play multiple formats",
...         "Runs are whole numbers",
...         "Average contains decimal values",
...         "Centuries are whole numbers",
...         "Shows player active or not",
...         "Stores runs format-wise"
...     ]
... }
>>> table = pd.DataFrame(data)
... 
>>> print(tabulate(table, headers="keys", tablefmt="grid"))
... 
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|    | Data field identifier   | Data type   | Example                                   | Reason                               |
+====+=========================+=============+===========================================+======================================+
|  0 | player_name             | String      | Virat Kohli                               | Names contain letters and characters |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  1 | player_age              | Integer     | 36                                        | Age is a whole number                |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  2 | country                 | String      | India                                     | Country names are text               |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  3 | teams_played            | List        | ['India', 'RCB']                          | Player can play for multiple teams   |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  4 | formats_played          | List        | ['Test', 'ODI', 'T20']                    | Player can play multiple formats     |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  5 | total_runs              | Integer     | 26000                                     | Runs are whole numbers               |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  6 | batting_average         | Float       | 52.3                                      | Average contains decimal values      |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  7 | centuries               | Integer     | 80                                        | Centuries are whole numbers          |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  8 | is_active_player        | Boolean     | True                                      | Shows player active or not           |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
|  9 | runs_by_format          | Dictionary  | {'Test': 9000, 'ODI': 13000, 'T20': 4000} | Stores runs format-wise              |
+----+-------------------------+-------------+-------------------------------------------+--------------------------------------+
